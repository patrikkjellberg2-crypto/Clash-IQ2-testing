Clash IQ Android image resources

Copy the contents of app/src/main/res/ into native-android/app/src/main/res/ in the repository.
Ensure AndroidManifest.xml uses android:icon="@mipmap/ic_launcher".
The full supplied artwork is available as @drawable/clash_iq_logo.
The launcher icon uses a centered square crop of the supplied image.
These assets are prepared but have not been committed to GitHub.
